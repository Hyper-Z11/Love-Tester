# Me and You
# DON'T MODIFY THIS FILE PLEASE!!!
import random

# Credit
print("Made by Hyper-Z11")
print("[https://github.com/Hyper-Z11/]\n")
print("Good Lucky :D \n")

# Input Enter
x = input("Your name: ")
y = input("Your partner name: ")

# Output x and y using z
z = print(x + " love " + y)
print("\n")

# Random Bool
randInt = random.uniform(0.0, 100.0)
print(randInt)

# To exit
input("Press enter to exit \n")
exit()
